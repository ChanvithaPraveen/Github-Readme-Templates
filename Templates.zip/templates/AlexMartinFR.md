### Bonjour 🙂

I'm Alex, Holistic Devsigner 🎨

Colors and words are the runes of our Modern World. When wielded carefully, their power can help your creations shine through the noise!

|T|h|i|n|g|s||I||💚|:|
| - | - | - | - | - | - | - | - | - | - | - |
| | | |`P`| | | | | | |`W`|
| |`D`|`E`|`S`|`I`|`G`|`N`| | | |`H`|
|`M`| | |`Y`| | | | |`C`| |`I`|
|`I`| | |`C`|`O`|`D`|`E`| |`O`| |`M`|
|`N`| | |`H`| | | | |`L`| |`S`|
|`I`| |`S`|`O`|`C`|`I`|`O`|`L`|`O`|`G`|`Y`|
|`M`| | |`L`| | | | |`R`| | |
|`A`| | |`O`| | | | | | | |
|`L`|`I`|`N`|`G`|`U`|`I`|`S`|`T`|`I`|`C`| |
|`I`| | |`Y`| | |`E`| | | | |
|`S`| | | | | |`M`| | |[📸](https://www.instagram.com/alexmartinfr/)| |
|`M`| | | | | | | | | | |

- 🛠 Contributing to [ Pest ](https://github.com/pestphp/pest) & [ Collision ](https://github.com/nunomaduro/collision)
- 🔥 Working with the [ TALLStack ](https://tallstack.dev/)
- 🐦 Reach me on [ Twitter ](https://twitter.com/alexmartinfr)

-----
Credits: [AlexMartinFR](https://github.com/AlexMartinFR)

Last Edited on: 30/08/2020