[![Linkedin Badge](https://img.shields.io/badge/-sanketpatil-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/sanket-patil-b4134362/)](https://www.linkedin.com/in/sanket-patil-b4134362/) [![Twitter Badge](https://img.shields.io/badge/-@sanket__patil-1ca0f1?style=flat-square&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://twitter.com/sanket__patil)](https://twitter.com/sanket__patil) [![Facebook Badge](https://img.shields.io/badge/-@____sanket____patil____-3b5998?style=flat-square&labelColor=3b5998&logo=facebook&logoColor=white&link=https://www.facebook.com/profile.php?id=100004711200725&sk=about)](https://www.facebook.com/profile.php?id=100004711200725&sk=about) [![Instagram Badge](https://img.shields.io/badge/-@____sanket____patil____-D7008A?style=flat-square&labelColor=D7008A&logo=Instagram&logoColor=white&link=https://www.instagram.com/____sanket____patil____/)](https://www.instagram.com/____sanket____patil____/) 
 

### Hey 👋🏽, I'm [Sanket! - www.sanketpatil.me](https://www.sanketpatil.me)  
<p align="left"> <img src="https://komarev.com/ghpvc/?username=sanket9006" alt="sanket9006" /> </p> 


<br/>

Hi, I'm Sanket Patil, a Web Developer and Cloud Developer 🚀 from Pune, India, currently, I'm a  Team Member 🙍🏽‍♂️ [@IoT-Club](https://jscoeiotclub.in/), Intern 👨🏽‍💻 [@Indihatt](https://indihatt.com/), Internee 👨🏽‍💼[@21ci](http://www.21ci.com/index.html) and a  Research Intern [@IntechOlympiad](https://portal.coepvlab.ac.in/InTechOlympiad/). Beside's Computer Science, I love photography. 

####      ![](https://img.shields.io/badge/Web%20Designing-%3C%2F%3E-blueviolet) ![](https://img.shields.io/badge/Google%20Cloud-%3C%2F%3E-yellow) ![](https://img.shields.io/badge/Python-%7C-0%2C%2022%2C%20100) ![](https://img.shields.io/badge/C++-%7C-yellowgreen) ![](https://img.shields.io/badge/Augmented%20Reality-%7C-blue) ![](https://img.shields.io/badge/SEO-%7C-ff69b4) ![](https://img.shields.io/badge/Testing-%3C%2F%3E-blueviolet)
  
**Talking about Personal Stuffs:**

- 👨🏽‍💻 I’m currently partcipating in as much Hackathons as I can
- 🌱 I’m currently learning GraphQL and DevOps
- 💬 Ask me about anything, I am happy to help
- ⚡️ Fun-Fact: I started writing blogs, by publishing them on my own website [sanketpatil.me](https://www.sanketpatil.me/) in 2020
- 📫 How to reach me: sanket.9006@gmail.com
- 📝[Resume](https://www.sanketpatil.me/wp-content/uploads/2020/07/Sanket-Patil-_-Rsesume.pdf)

**Languages and Tools:**   

<code><img height="20" src="https://raw.githubusercontent.com/github/explore/5c058a388828bb5fde0bcafd4bc867b5bb3f26f3/topics/graphql/graphql.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/cpp/cpp.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/python/python.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/mysql/mysql.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/firebase/firebase.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/terminal/terminal.png"></code>

**Achievement**  

- DECOV 2020 [Code of Tigers] - 1st Prize - Education Domain 
- DSC BVP Manidesto - 1st Prize - Application Making
- Hack the Hour Glass - 1st Prize - AR/VR Domain 
- World Hackers - Best Try Award
- Qwiklabs - Winner of the Week
- Hack the Hour Glass - Wolfram Award
- Hack in India - Top 20 Teams



![Sanket's github stats](https://github-readme-stats.vercel.app/api?username=sanket9006&show_icons=true&theme=radical)

![Dino](https://raw.githubusercontent.com/sanket9006/sanket9006/master/dino.gif)


----
Credit: [sanket9006](https://github.com/sanket9006)

Last Edited on: 23/09/2020