
<h1 align="center">
  
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Architects+Daughter&size=26&color=%23DFC6B4&center=true&vCenter=true&lines=Hi%2C+It's+Farah!;Full-Stack+Developer;Tech+enthusiast;and+an+Open-Source+Supporter)](https://git.io/typing-svg)
</h1>

<p align="center">
  I am Farah AIT ELAHMADI, graduated with a Bachelor's degree specialised in Web Programming and Technologies, and supporter of the open-source  movement philosophy.<br>
  I am always doing that which i cannot do in order that i may learn how to do it,<br> and i believe in sharing knowledge.<br>
  I think it's essential always to keep professional and surround yourself with good people,<br> work hard, and be nice to everyone.
<p/>
<p align="center">
  <a href="mailto:farahaitelahmadi@gmail.com">
     <img  src="https://img.shields.io/badge/email-red?style=for-the-badge&logo=gmail&logoColor=white" alt="email">
  <a/>&nbsp;
  <a href="https://www.linkedin.com/in/farah-ahmadi">
     <img  src="https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="email">
  <a/>&nbsp;
  <a href="https://twitter.com/ahmadiF__">
     <img  src="https://img.shields.io/badge/twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white" alt="twitter">
  <a/>&nbsp;
  <a href="https://farahelahmadi.me">
     <img  src="https://img.shields.io/badge/website-C3897E?style=for-the-badge&logo=about.me&logoColor=white" alt="website">
  <a/>
<p/>

<h1><h1/>
<p align="center">
 <img src="https://media.giphy.com/media/W5eoZHPpUx9sapR0eu/giphy.gif" width="30px" alt="Git"/>&nbsp;<i><b>Git Activeness</b></i></p>
 
<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=ray0emma&show_icons=true&locale=en&layout=compact&theme=gruvbox" alt="ovi" /></p>
<p>&nbsp;<img align="right" src="https://github-readme-stats.vercel.app/api?username=ray0emma&show_icons=true&locale=en&theme=gruvbox" alt="ovi" width="410" /></p>
<br><br><br><br><br>

![𝚐𝚒𝚝𝚑𝚞𝚋 𝚐𝚛𝚊𝚙𝚑](https://activity-graph.herokuapp.com/graph?username=ray0emma&theme=gruvbox&hide_border=true&area=true)


<h4 align="center">
  
Credit: [Ray0Emma](https://github.com/Ray0Emma)

Last Edited on: 29/10/2021.
  
</h4>
