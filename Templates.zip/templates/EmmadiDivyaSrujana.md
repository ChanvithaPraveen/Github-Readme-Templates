   ###   Hello World! :yellow_heart:
<img alt="GIF" src="https://i.pinimg.com/originals/9e/a7/2e/9ea72ef078139ced289852e8a4ea0c5c.gif" width = 200/>

<hr>

## My Skills :computer:

- **Programming Languages**
<table>
<tbody>
 <tr>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/python/python-ar21.svg"> 
</td>

<td align="center" width="50%">
<img height=80px src="https://raw.githubusercontent.com/isocpp/logos/master/cpp_logo.png"> 
</td>

</tr>

</tbody>
</table>


- **Web Development**
<table>
<tbody>
 <tr>
<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/w3_html5/w3_html5-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=70px src="https://1000logos.net/wp-content/uploads/2020/09/CSS-Logo.png"> 
</td>

<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/getbootstrap/getbootstrap-ar21.svg"> 
</td>

</tr>

 <tr>
<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/javascript/javascript-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/postgresql/postgresql-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/mysql/mysql-ar21.svg"> 
</td>

</tr>

</tbody>
</table>

<hr>

## Currently Learning :beginner:

- **Data Science**

<table>
<tbody>
 <tr>
<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/numpy/numpy-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=60px src="https://upload.wikimedia.org/wikipedia/commons/e/ed/Pandas_logo.svg"> 
</td>

<td align="center" width="33%">
<img height=80px src="https://www.vectorlogo.zone/logos/opencv/opencv-ar21.svg"> 
</td>
</tr>

</tbody>
</table>

- **Web Development**
<table>
<tbody>
 <tr>
<td align="center" width="100%">
<img height=60px src="https://www.vectorlogo.zone/logos/djangoproject/djangoproject-ar21.svg"> 
</td>

</tr>

</tbody>
</table>


<hr>

## Thank you for visiting my profile. You're a gem. :gem:

![Visitor Count](https://profile-counter.glitch.me/EmmadiDivyaSrujana/count.svg)

<hr>

## Connect with me. :smiley:

<p>
<a href="https://github.com/EmmadiDivyaSrujana"><img src="https://img.shields.io/badge/-Emmadi_Divya_Srujana-black?logo=github&style=flat-square"/></a>
<a href="https://www.linkedin.com/in/emmadi-divya-srujana-19baa0182/"><img src="https://img.shields.io/badge/-Emmadi_Divya_Srujana-blue?logo=linkedin&style=flat-square"></a>
<a href="https://instagram.com/divyasrujana?igshid=esstkghnur2d"><img src="https://img.shields.io/badge/-Divya_Srujana-pink?logo=instagram&style=flat-square"/></a>
<a href="mailto:edsrujana1@gmail.com"><img src="https://img.shields.io/badge/-edsrujana1@gmail.com-black?logo=gmail&style=flat-square"/></a>
<a href="https://twitter.com/divya_emmadi"><img src="https://img.shields.io/badge/-divya__emmadi-blue?logo=twitter&style=flat-square"/></a>
</p>

-----
Credits: [EmmadiDivyaSrujana](https://github.com/EmmadiDivyaSrujana)

Last Edited on: 29/11/2020