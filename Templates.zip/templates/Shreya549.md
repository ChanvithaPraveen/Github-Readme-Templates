### Hello World, I'm Shreya :purple_heart:
<img alt="GIF" src="https://media.giphy.com/media/Cmr1OMJ2FN0B2/giphy.gif" width = 200/>

-----
#### I am an individual with a keen eye for details, seeking to advance my growing tech career as a Software Developer and bringing my trouble shooting skills to engineer responsive solutions along with like-minded peers.

### My skills :woman_technologist:
- **Competitive Coding**
<table>
<tbody>
 <tr>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/python/python-ar21.svg"> 
</td>

<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/java/java-ar21.svg"> 
</td>
</tr>
</tbody>
</table>

- **Web Development**
<table>
<tbody>
 <tr>
<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/djangoproject/djangoproject-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=60px src="https://www.vectorlogo.zone/logos/mysql/mysql-official.svg"> 
</td>

<td align="center" width="33%">
<img height=100px src="https://www.vectorlogo.zone/logos/postgresql/postgresql-vertical.svg"> 
</td>

</td>

</tr>


<td align="center" width="33%">
<img height=100px src="https://www.vectorlogo.zone/logos/javascript/javascript-ar21.svg"> 
 
<td align="center" width="33%">
<img height=100px src="https://www.vectorlogo.zone/logos/nodejs/nodejs-ar21.svg"> 
</td>

<td align="center" width="33%">
<img height=100px src="https://www.vectorlogo.zone/logos/w3_html5/w3_html5-ar21.svg"> 
</td>
<tr>
 
 </tr>
</tbody>
</table>

- **Data Science**
  - Data Visualization
  - Data Analysis
 <table>
<tbody>
 <tr>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/python/python-ar21.svg"> 
</td>

<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/r-project/r-project-icon.svg"> 
</td>
</tr>
</tbody>
</table>

### I'm currently learning :open_book:
- **Competitive Coding**
    - Dynamic Programming
    
- **Web Development**
<table>
<tbody>
 <tr>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/graphql/graphql-ar21.svg"> 
</td>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/reactjs/reactjs-ar21.svg"> 
</td>
</tr>
</tbody>
</table>

 - **Data Science**
   - Machine Learning
   - Artificial Intelligence
    
<br>
<p align="center">
<img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Shreya549&layout=compact&theme=radical" alt="My Github Stats">
<img align="center" src="https://github-readme-stats.vercel.app/api?username=Shreya549&&show_icons=true&theme=radical&count_private=true&include_all_commits=true" alt="My Github Stats">
</p>

<br> <br>
 <a href="https://twitter.com/shreyaaaaaaaaa_">
  <img align="left" alt="Shreya's Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />
</a>
<a href="https://www.linkedin.com/in/shreyachatterjee05/">
  <img align="left" alt="Shreya's LinkedIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://github.com/Shreya549">
  <img align="left" alt="Shreya's Github" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/github.svg" />
</a>
<a href="https://www.instagram.com/the_strange_concoction/">
  <img align="left" alt="Shreya's Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />
</a>
<a href="https://www.facebook.com/shreya.chatterjee.31105674">
  <img align="left" alt="Shreya's Facebook" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/facebook.svg" />
</a>
<a href="https://www.hackerrank.com/shreyachatterje2">
  <img align="left" alt="Shreya's Hackerrank" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/hackerrank.svg" />
</a>
<br><br>

#### Thanks for visiting :heart:
![VisitorCount](https://profile-counter.glitch.me/Shreya549/count.svg)



<br>
<br>

<!--
<table>
<tbody>
 <tr>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/graphql/graphql-ar21.svg"> 
</td>
<td align="center" width="50%">
<img height=60px src="https://www.vectorlogo.zone/logos/reactjs/reactjs-ar21.svg"> 
</td>
</tr>
</tbody>
</table>
<br>
<p align="center">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Shreya549&theme=radical" />
<img align="center" src="https://github-readme-stats.vercel.app/api?username=Shreya549&&show_icons=true&theme=radical" alt="My Github Stats">
</p>
<a href="https://github.com/Shreya549">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Shreya549&theme=radical" />
</a>
**Shreya549/Shreya549** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

----
Credit: [Shreya549](https://github.com/Shreya549)

Last Edited on: 23/09/2020