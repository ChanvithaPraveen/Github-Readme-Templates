![Peek 2020-07-09 15-53](https://user-images.githubusercontent.com/7910856/87048834-84abea80-c1fc-11ea-9342-27b96a046ba4.gif)

<p align="center">
<a href= "https://blog.mphomphego.co.za/"><img src="https://img.icons8.com/material-outlined/26/000000/ball-point-pen.png"/></a>
<a href= "https://www.linkedin.com/in/mphomphego/"><img src="https://img.icons8.com/material-outlined/30/000000/linkedin.png"/></a>
<a href= "https://www.youtube.com/c/MphoMphego1"><img src="https://img.icons8.com/material-outlined/30/000000/youtube.png"/></a>
<a href= "https://dev.to/mmphego"><img src="https://img.icons8.com/windows/32/000000/dev.png"/></a>
<a href= "https://twitter.com/mphomphego"><img src="https://img.icons8.com/material-outlined/30/000000/twitter.png"/></a>
</p>

<p  align="center">
  <a href="https://raw.githubusercontent.com/mmphego/mmphego/master/resources/mpho.mp3">How to pronounce my name!</a></br>
  <!-- <img src="https://visitor-badge.glitch.me/badge?page_id=mmphego.mmphego" alt="visitor count"/></br> -->
  <img src="https://github-readme-stats.vercel.app/api/?username=mmphego&show_icons=true&title_color=fffffff&icon_color=000000&text_color=000000" alt="github stats"/></br>
</p>

-----
Credits: [mmphego](https://github.com/mmphego)

Last Edited on: 30/08/2020