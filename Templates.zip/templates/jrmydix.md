<h1 align="center">Hi! I'm Jérémy 🙂</h1>
<h4 align="center">I'm a 20 years old junior web developer based in France.</h4>

<br><br><h2 align="center">Contact:</h2><br>

<div align="center">
<a href="https://www.linkedin.com/in/jeremy-cusinmermet/"><img src="https://img.shields.io/badge/-LinkedIn-0a66c2?style=for-the-badge&logo=linkedin&logoColor=fff&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
<a href="https://github.com/jrmydix"><img src="https://img.shields.io/badge/-Github-f0f6fc?style=for-the-badge&logo=github&logoColor=fff&labelColor=282828"></a>

<br><br>
📧 Mail : jeremy.cusinmermet@pm.me

🔗 Personnal website : [jeremy-cusinmermet.xyz](https://jeremy-cusinmermet.xyz)

</div><br>

<hr>

<br><h2 align="center">Skills:</h2><br>

<p>
<div align="center">
  <img src="https://img.shields.io/badge/-HTML-ff6600?style=for-the-badge&logo=html5&logoColor=ff6600&labelColor=282828">
  
  <br><img src="https://img.shields.io/badge/-CSS-264ee4?style=for-the-badge&logo=css3&logoColor=264ee4&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <img src="https://img.shields.io/badge/-Sass-bf4080?style=for-the-badge&logo=sass&logoColor=bf4080&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <img src="https://img.shields.io/badge/-Bootstrap-860afb?style=for-the-badge&logo=bootstrap&logoColor=860afb&labelColor=282828">

<br><img src="https://img.shields.io/badge/-JavaScript-f7df1e?style=for-the-badge&logo=javascript&logoColor=f7df1e&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="https://img.shields.io/badge/-React-5cd9ff?style=for-the-badge&logo=react&logoColor=5cd9ff&labelColor=282828">

<br><img src="https://img.shields.io/badge/-PHP-787cb4?style=for-the-badge&logo=php&logoColor=787cb4&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="https://img.shields.io/badge/-Symfony-fff?style=for-the-badge&logo=symfony&logoColor=fff&labelColor=282828">

<br><img src="https://img.shields.io/badge/-SQL-eee?style=for-the-badge&logo=mysql&logoColor=eee&labelColor=282828">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img src="https://img.shields.io/badge/-Git-f05030?style=for-the-badge&logo=git&logoColor=f05030&labelColor=282828">

</div>
</p><br>

<hr>

<br><h2 align="center">Stats:</h2><br>

<div align="center">

![Views](https://komarev.com/ghpvc/?username=jrmydix&label=Profile+visitors:)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=jrmydix&layout=compact&theme=dark)](https://github.com/jrmydix)

![Jérémy's GitHub stats](https://github-readme-stats.vercel.app/api?username=jrmydix&count_private=true&show_icons=true&theme=dark&hide=issues)

</div><br>

---

Credits: [jrmydix](https://github.com/jrmydix)

Last edited on: 31/01/2022
