
<img src="https://github.com/maneprajakta/Data_Cleaning_With_Python/blob/master/ezgif.com-video-to-gif.gif" width="1650" height="250" />

# Hello, folks! <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">




- 🔭 I’m currently working on will be sharing once done .
- 🌱 I’m currently learning OpenCv and Deep Learning concpets and implementations.
- 👯 I’m looking to collaborate on OpenCv projects .
- 💬 Ask me about Learning path for Machine Learning and Data Analyst.
- 📫 How to reach me: mail at prajakta916mane1@gmail.com

## Can Help You With :star: :star:  :
- Provinding Complete insight of you Data including EDA.
- Applaying Machine Learning Concepts to Solve real life Problem.
- Complete Data Manipulation starting from scrapping to dataframe.


## Github STATS :cyclone: !

![Prajakta's github stats](https://github-readme-stats.vercel.app/api?username=maneprajakta&show_icons=true&theme=radical)
<br>

## Some Repos to Visit :blossom: !
![ReadMe Card](https://github-readme-stats.vercel.app/api/pin/?username=maneprajakta&repo=Digit_Recognition_Web_App&show_icons=true&theme=radical)
![ReadMe Card](https://github-readme-stats.vercel.app/api/pin/?username=maneprajakta&repo=DSA&show_icons=true&theme=radical)

## Open For Oppurtunities :purple_heart: !

-----
Credits: [maneprajakta](https://github.com/maneprajakta)

Last Edited on: 30/08/2020
