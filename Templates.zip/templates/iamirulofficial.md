<p align="center">
  <img src="https://media.giphy.com/media/IhO5Kk5sPEOPshs4n4/giphy.gif" width="40%">
  <br />
  <br />
  <samp>
   <!-- I'm Aadi :wave: -->
    <a href="https://dev.to/iamirulofficial">
  <img src="https://d2fltix0v2e0sb.cloudfront.net/dev-badge.svg" alt="Amirul Islam's DEV Profile" height="30" width="30">
</a>
    <br />
    <br />
    Software Engineering !
    <br />
    <br />
    * #DevCommunity * #100DaysOfCode * #100DaysOfMLCode * ML/DL/RL Enthusiasts * Flutter * ReactJs * MySql *
                  <br> || Can code in c++, python, Java || <br>
                        Loving Life🌼♥️🥰
  </samp>
</p> 
 <!-- ![Aadi Github Stats](https://github-readme-stats.vercel.app/api?username=iamirulofficial&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515)-->



<p align="center">
<a href="https://github-readme-stats.vercel.app/api?username=iamirulofficial&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515">
  <img src="https://github-readme-stats.vercel.app/api?username=iamirulofficial&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515" />
</a>
<br />
<br />
<a href="https://twitter.com/aadicodes"><img src= "https://img.shields.io/twitter/url/https/twitter.com/cloudposse.svg?style=social&label=Follow%20%40aadicodes" /></a></p>
<br />



<p align="center">
  Made with :heart: &nbsp;using GitHub Markdown by Aadi
  <br />
  <br />
  <img src="https://media.giphy.com/media/jpVnC65DmYeyRL4LHS/giphy.gif" width="20%">
</p>
----
Credit: [iamirulofficial](https://github.com/iamirulofficial)

Last Edited on: 23/09/2020