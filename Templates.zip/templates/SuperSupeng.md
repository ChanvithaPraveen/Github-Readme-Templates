![gif](https://github.com/SuperSupeng/SuperSupeng/blob/master/about.gif)

何以解忧，唯有暴富。💰

[![Subranium's github stats](https://github-readme-stats.vercel.app/api?username=SuperSupeng&show_icons=true&theme=merko)](https://github.com/anuraghazra/github-readme-stats) [![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=SuperSupeng&layout=compact&theme=merko)](https://github.com/anuraghazra/github-readme-stats)

-----
Credits: [SuperSupeng](https://github.com/SuperSupeng)

Last Edited on: 30/08/2020