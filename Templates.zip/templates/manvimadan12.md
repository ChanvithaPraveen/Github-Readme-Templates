### Hi there 👋

<!--
**manvimadan12/manvimadan12** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.-->

<h3 align="center">I am Manvi Madan. I am a Data Scientist working in Aucland,NZ.</h3>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=rajputjay41&label=Profile%20views&color=0e75b6&style=flat" alt="manvimadan12" /> </p>

<p align="left"> <a href="https://github.com/ryo-ma/github-profile-trophy"><img src="https://github-profile-trophy.vercel.app/?username=manvimadan12" alt="manvimadan12" /></a> </p>

- 🔭 I’m currently working on [#100DaysOfDeepLearning](https://www.instagram.com/ml.newzealand/) Challenge
- 🌱 I’m currently learning about Computer Vision with Deep Learning
- 💬 Ask me about : Business, Neuroscience, Data Science, FinTech, Machine Learning, AI Ethics, Job search in NZ....
- 📫 How to reach me: [LinkedIn](https://nz.linkedin.com/in/manvimadan?challengeId=AQFP41gYUVTWXgAAAXTdLTLUD1ouI-Slkj6j1vSVIpFSPFDELixPuQAPkSBK4_beV-6747rXSKjHK4dkQeuwCiK23vil0RopCg&submissionId=172312d1-e273-3916-9781-05335d3a4409), DM on [Instagram](https://www.instagram.com/ml.newzealand/) or email me at manvimadan@outlook.com


**Languages and Tools:**  
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/Rlogo.svg"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/python.jpg"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/powerbi2.jpg"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/sql.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/Tensorflow_logo.svg.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/opencv.png"></code>  
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/jupyter.jpeg"></code>  
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/vscode.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/spark.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/rstudio.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/matlab.png"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/hadoop%20logo.jpg"></code>
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/excel.jpg"></code>  
<code><img height="20" src="https://github.com/manvimadan12/manvimadan12/blob/master/images/1200px-Spyder_logo.svg.png"></code>  




<a href="https://github.com/manvimadan12/github-readme-stats">
  <img align="center" src="https://github-readme-stats.vercel.app/api?username=manvimadan12&show_icons=true&include_all_commits=true&theme=radical" alt="Manvi's github stats" />
</a>

<a href="https://github.com/manvimadan12/github-readme-stats">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=manvimadan12&layout=compact&theme=radical" />
</a> 

<a href="https://github.com/manvimadan12/Becoming-ML_engineer">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=manvimadan12&repo=Becoming-ML_engineer&theme=radical" />
</a>


<a href="https://github.com/manvimadan12/ML-Research-Papers-">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=manvimadan12&repo=ML-Research-Papers-&theme=radical" />
</a>   

<a href="https://github.com/manvimadan12/Computer_Vision_Roadmap">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=manvimadan12&repo=Computer_Vision_Roadmap&theme=radical" />
</a>   

<a href="https://github.com/manvimadan12/workout-training-using-ml">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=manvimadan12&repo=workout-training-using-ml&theme=radical" />
</a>   

-----
Credits: [Manvi Madan](https://github.com/manvimadan12)

Last Edited on: 30/11/2020