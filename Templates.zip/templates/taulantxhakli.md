## ![](https://mario.wiki.gallery/images/6/66/DK64_Yellow_Banana.gif) Welcome To My Cave ![](https://mario.wiki.gallery/images/6/66/DK64_Yellow_Banana.gif)

- 🛠 I am currently working on my portfolio and resume
- 🌴 I am currently perfecting my craft
- 🤝 I am looking to collaborate on any open source project
- 📧 How to reach me: txhakli@gmail.com

## 🔧 Technologies Stack 🔧
![](https://img.shields.io/badge/OS-Mac-informational?style=flat&logo=apple&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/OS-Windows-informational?style=flat&logo=windows&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/OS-Linux-informational?style=flat&logo=linux&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-HTML5-informational?style=flat&logo=html5&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-CSS3-informational?style=flat&logo=css3&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-PHP-informational?style=flat&logo=php&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-JavaScript-informational?style=flat&logo=javascript&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-Python-informational?style=flat&logo=python&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-csharp-informational?style=flat&logo=csharp&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-SQL-informational?style=flat&logo=mysql&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Code-Swift-informational?style=flat&logo=swift&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/Shell-Bash-informational?style=flat&logo=gnu-bash&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/GitHub-Git-informational?style=flat&logo=git&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/IDE-VSCode-informational?style=flat&logo=visualstudiocode&logoColor=white&color=blueviolet)
![](https://img.shields.io/badge/IDE-Xcode-informational?style=flat&logo=xcode&logoColor=white&color=blueviolet)

## ⚙️ GitHub Stats ⚙️

<a href="https://github.com/taulantxhakli/taulantxhakli">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=taulantxhakli&hide=java,html,tex&title_color=ffffff&text_color=c9cacc&icon_color=blueviolet&bg_color=1d1f21&langs_count=3" />
</a>
<a href="https://github.com/taulantxhakli/taulantxhakli">
  <img align="center" src="https://github-readme-stats.vercel.app/api?username=taulantxhakli&show_icons=true&line_height=27&count_private=true&title_color=ffffff&text_color=c9cacc&icon_color=blueviolet&bg_color=1d1f21" alt="Taulant's GitHub Stats" />
</a>

<a href="https://github.com/taulantxhakli/Discrimination">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=taulantxhakli&repo=Discrimination&title_color=ffffff&text_color=c9cacc&icon_color=blueviolet&bg_color=1d1f21" />
</a>


<a href="https://github.com/taulantxhakli/taulantxhakli.github.io">
  <img align="center" src="https://github-readme-stats.vercel.app/api/pin/?username=taulantxhakli&repo=taulantxhakli.github.io&title_color=ffffff&text_color=c9cacc&icon_color=blueviolet&bg_color=1d1f21" />
</a>  

------
Credit: [taulantxhakli](https://github.com/taulantxhakli)
Last Edited on : 09/08/2021
