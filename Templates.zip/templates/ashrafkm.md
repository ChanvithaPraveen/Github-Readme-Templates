<img align='right' src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="230">

## नमस्ते 🙏, I'm ASHRAF K.M 
## Full Stack Developer 👨‍💻

<!--
**ashrafkm/ashrafkm** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->




[![](https://img.shields.io/badge/LinkedIn-ashrafkm-blue)](https://www.linkedin.com/in/ashraf-k-m-149a3494/)
[![](https://img.shields.io/badge/Gmail-ashrafkm010%40gmail.com-red)](mailto:ashrafkm010@gmail.com)


### <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="50"> A little more about me...  

```javascript
const ashraf = {
    pronouns: "He" | "Him",
    askMeAbout: ["app dev", "web dev", "tech"],
    technologies:{
        backEnd: ["nodejs", "express", "python"],
        fronEnd: ["angular"],
        mobileApp: ["ionic","angular"],
        database: ["mongo","mySql"],
        serverless: ["mongo-realm","aws-lambda"],
        devOps: ["AWS", "Nginx", "Jenkins"],
        misc: ["Firebase", "Socket.IO"]
    },
    architecture: ["Serverless Architecture", "microservices", "event-driven", "Single page applications"],
}
```

---
⭐️ From [@ashrafkm](https://github.com/ashrafkm)


----
Credit: [ashrafkm](https://github.com/ashrafkm)

Last Edited on: 08/09/2020