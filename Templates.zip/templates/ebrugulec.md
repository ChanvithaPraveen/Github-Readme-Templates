<h1> Hey 👋, I'm Ebru!</h1>
</h1>

### A little about me...
I'm a **Software Engineer** at **[Trendyol](https://github.com/Trendyol)**. I'm a *Tech Enthusiast* passionate about learning and working with new technologies.<br/>

### A few quick facts
- 🔭 &nbsp; I’m currently working with Nodejs, Express, React,
Graphql, Mongodb, Javascript, Java etc.
- 🌱 &nbsp; I’m currently learning Full Stack Development.
- 😄 &nbsp; Pronouns: developer, dancer and day dreamer
- 💬 &nbsp; Ask me about anything, I am happy to help

### Projects and dev stuffs:

<details>	
  <summary><b>⚡ Github Stats</b></summary>
</details>

<details>
  <summary><b>👩‍💻 &nbsp; Open Source Projects</b></summary>
</details>

### So, let's meet!
You can check out my projects and also you can find me on [Linkedin](https://tr.linkedin.com/in/glcebru)
-----
Credits: [ebrugulec](https://github.com/ebrugulec)

Last Edited on: 15/01/2021