## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px"> Hey Everyone<img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="30px">, This is Hrugved😃 <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">

<hr style="height:2px;border-width:1;border-radius: 5px;color:gray;background-color:#8080ff">

- 👋🏻 Hiya, I’m <a href="https://hrugved06.github.io/Portfolio-Hrugved-Kolhe/">HrugVed</a> ✌🏻 <br/> 
- 👀 I’m interested in Machine Learning, DSA, Open Source and Many more 😄<br/>
- 🌱 Trying to learn new technologies and try to keep myself busy 🤵🏻 <br/>
- 👨🏻‍💻 Currently exploring Open Source field 📱</br>
- 💞️ I’m open for collaboration on every interesting project/stuff ✌🏻<br/>
- 📫 You can contact me through these socials IDs 😁👇🏻  <br/>

<!-----Social Accounts------>

<p align="center">
<a href="https://hrugved06.github.io/Portfolio-Hrugved-Kolhe/">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/external-itim2101-lineal-color-itim2101/40/000000/external-resume-business-recruitment-itim2101-lineal-color-itim2101.png"/>
</a>

<a href="https://www.linkedin.com/in/hrugved-kolhe-364881193/">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/doodle/40/000000/linkedin--v2.png"/>
</a>

<a href="https://twitter.com/HrugVed_">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/nolan/40/twitter.png"/>
</a>

<a href="https://www.instagram.com/_hrugved_/">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/doodle/38/000000/instagram--v1.png"/>
</a>

<a href="https://t.me/Dev1ce_06">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/doodle/40/000000/telegram-app.png"/>
</a>

<a href="https://discord.com/channels/@me/862133669510250506">
<img border="0" alt="HrugVed (He/Him)#8131" src="https://img.icons8.com/fluent/42/000000/discord-logo.png"/>
</a>

<a href="mailto:hskolhe666@gmail.com">
<img border="0" alt="Hrugved Kolhe" src="https://img.icons8.com/doodle/38/000000/gmail-new.png"/>
</a>
</p>

<!--  <a href="https://tawk.to/chat/61001d75d6e7610a49ad3be2/1fbk764uk">
<img border="0" alt="yawk.to" src="https://img.icons8.com/fluent/42/000000/discord-logo.png"/>
</a> -->
 
<hr style="height:2px;border-width:1;border-radius: 5px;color:#8080ff;background-color:#8080ff">

<!-----Contribution figures------>

## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">General Stats :

<img align="center" src = "https://github-readme-stats.vercel.app/api?username=hrugved06&&show_icons=true&title_color=02D752&icon_color=bb2acf&text_color=b3b3ff&bg_color=0,000000,130F40">

<hr style="height:2px;border-width:1;border-radius: 5px;color:gray;background-color:#8080ff">

<!------------ Streak Display -------------->

## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">Contribution Stats :

<div>
<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=hrugved06&theme=dark" alt="HrugVed" /></p>
</div>

<hr style="height:2px;border-width:1;border-radius: 5px;color:#8080ff;background-color:#8080ff">


<!-------------Projects---------------->

## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">Repository Overview :

<a href="https://github.com/hrugved06/Playing-TRex-game-using-facial-recognition">
 <img align='center' src="https://github-readme-stats.vercel.app/api/pin/?username=hrugved06&repo=TRex-game-using-facial-recognition&theme=dark" />
</a>

<a href="https://github.com/hrugved06/Discbot_ai">
 <img align='center' src="https://github-readme-stats.vercel.app/api/pin/?username=hrugved06&repo=Discbot_ai&theme=dark" />
</a>

<a href="https://github.com/hrugved06/Face-Blurring-and-Deblurring">
 <img align='center' src="https://github-readme-stats.vercel.app/api/pin/?username=hrugved06&repo=Face-Blurring-and-Deblurring&theme=dark" />
</a>

<a href="https://github.com/hrugved06/ML-DL-Projects">
 <img align='center' src="https://github-readme-stats.vercel.app/api/pin/?username=hrugved06&repo=ML-DL-Projects&theme=dark" />
</a>


</br>
<hr style="height:2px;#8080ffborder-width:0;border-radius: 5px;color:gray;background-color:#8080ff">

<!--------------- Hrugved's Contribution Graph ---------------->

## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">Contribution Graph :

 <img src="https://activity-graph.herokuapp.com/graph?username=hrugved06&bg_color=FFFFFF&color=000000&line=000000&point=00FF00"></div>
 
 <hr style="height:2px;border-width:1;border-radius: 5px;color:#8080ff;background-color:#8080ff">
 
 </br>
 
<!------------------- Languages used by me ----------------------->

## <img src="https://media.giphy.com/media/iY8CRBdQXODJSCERIr/giphy.gif" width="30px">Programming Languages used in the Project:


<a href="https://www.python.org/">
<img border="0" alt="Python" src="https://img.icons8.com/color//000000/python--v2.png"/>
</a>

<a href="https://jupyter.org/">
<img border="0" alt="Juyter" src="https://cdn.icon-icons.com/icons2/2107/PNG/48/file_type_jupyter_icon_130494.png"/>
</a>

<a href="https://html.com/#What_is_HTML">
<img border="0" alt="HTML" src="https://img.icons8.com/color/48/000000/html-5--v1.png"/>
</a>

<a href="https://en.wikipedia.org/wiki/CSS">
<img border="0" alt="CSS" src="https://img.icons8.com/color/48/000000/css3.png"/>
</a>

<a href="https://www.javascript.com/">
<img border="0" alt="JavaScript" src="https://img.icons8.com/color/50/000000/javascript--v1.png"/>
</a>


</br>
<hr style="height:2px;#8080ffborder-width:0;border-radius: 5px;color:gray;background-color:#8080ff">
</br>

Credits: [Hrugved Kolhe](https://github.com/hrugved06)

Last edited on: 13/09/2021

---