### Hello World
Hi, I'm [Windard](https://windard.com) 👋

![age](https://img.shields.io/badge/age-24-blue)
![focus](https://img.shields.io/badge/focus-backend-brightgreen)
![living](https://img.shields.io/badge/living-shanghai-3c9)
![visitors](https://visitor-badge.herokuapp.com/badge?page_id=windard.github.profile)

<br />

[![Windard's github stats](https://github-readme-stats.vercel.app/api?username=windard&show_icons=true)](https://github.com/windard)

----

Credits: [windard](https://github.com/windard)

Last Edited on: 31/08/2020
